'''
import discord
from discord.ext import commands
import responses
import asyncio
import music_player



intents = discord.Intents().all()
client = discord.Client(intents=intents)


async def send_message(message,user_message):
        try:
            response = responses.what_response(user_message)
            await message.channel.send(response)
        except Exception as e:
            print(e)


async def get_last_bot_message_id(channel):
    try:
        async for message in channel.history(limit=50):
            if message.author == client.user:
                return message.id
    except Exception as e:
        print(e)


async def add_text_to_message(channel, message_id, text_to_add):
    try:
        message = await channel.fetch_message(message_id)
        new_content = message.content + " " + text_to_add
        await message.edit(content=new_content)
    except Exception as e:
        print(e)


async def after_certain_time(message,user_message):
        try:
            print(message)
            remind = user_message[6:]
            user_message = user_message.lower()
            hour = user_message[:2]
            print(hour)
            hours = int(hour)
            minute = user_message[3:5]
            print(minute)
            minutes = int(minute)
            sum_seconds = hours*60*60 + minutes*60
            print(sum_seconds)
            await dm_channel.send(f"I will send the reminder in '{hour}' hours and '{minutes}' minutes!")
            await asyncio.sleep(sum_seconds)
            user = message.author
            dm_channel = await user.create_dm()
            username = str(message.author.name)
            await dm_channel.send(f"Hello {username}! You've asked me to tell you: '{remind}' {hour}:{minute} ago")
        except Exception as e:
            print(e)


async def help_response(message):
        try:
            print(message)
            user = message.author
            dm_channel = await user.create_dm()
            username = str(user.name)
            await dm_channel.send(f"Hello {username}!\nYou've asked me for help and here I am! Let me introduce you what can I do!")
            id_message = await get_last_bot_message_id(dm_channel)
            await asyncio.sleep(5)
            await add_text_to_message(dm_channel, id_message, "\n\nFirst thing you can ask me to do is show you how to use my built-in functions by writing '!help' as you just did. \nWhen written I will come to your dm to not spam server channels and tell you all you need to know about me!")
            await asyncio.sleep(5)
            await add_text_to_message(dm_channel, id_message, "\n\nThere's also a function that you can use by writing 'say: ' at beggining and later adding a sentence. If there is a prepared response then I will send the response to you.\nFor example:\nWhen user writes 'say: What time is it?' I will respond with:")
            await asyncio.sleep(1)
            await add_text_to_message(dm_channel, id_message,"https://tenor.com/bVx5d.gif")
            await asyncio.sleep(5)
            await add_text_to_message(dm_channel, id_message,"\n\nAnother function you can use is called by 'alarm in: ' to use it properly you can write for example 'alarm in: 01:05 Stop the rat race!'\nThis would make me send you a message after an hour and 5 minutes after the function was called.\nThe function was created to make life easier to people who easly forget about something and need to be reminded to do something after some time.\n(This was made mainly for my creator himself but you can also use it, don't worry.)")
            id_message = await get_last_bot_message_id(dm_channel)
            await asyncio.sleep(8)
            await add_text_to_message(dm_channel, id_message, "\n\nThat's all for now! Bye! Have a great day!")
        except Exception as e:
            print(e)


def run_friendlyface():

    @client.event   
    async def on_ready():
        print(f'Logged in as {client.user}')

    @client.event
    async def on_message(message):
        if message.author == client.user:
            return

        username = str(message.author)
        user_message = str(message.content)
        channel = str(message.channel)

        if user_message[:6] == "!say: ":
            user_message = user_message[6:]
            print(f"{username} said: '{user_message}' ({channel})")
            await send_message(message, user_message)

        elif user_message[:11] == "!alarm in: ":
            user_message = user_message[11:]
            print(f"{username} said: '{user_message}' ({channel})")
            await after_certain_time(message, user_message)

        elif user_message == "!help":
            print(f"{username} said: '{user_message}' ({channel})")
            await help_response(message)
    client.run("")
'''