#run this file to turn bot online
#the bot won't work due to lack of key in bot.run in friendlyface.py file
#the key is not provided here as it is private and should be kept safe
import friendlyface

if __name__ == '__main__':
    friendlyface.run_friendlyface();