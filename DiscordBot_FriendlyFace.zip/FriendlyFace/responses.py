#This file keeps responses the bot will give to the user after user will write proper sentence
#Note: This file and "say: " function was just first testing ground - they were quickly abandoned and were not developed since.
import discord
import datetime
def what_response(message) -> str:
    user_message = message.lower()

    if user_message == "hi":
        return "Hi to you too"
    elif user_message == "hello there":
        return "https://tenor.com/bmJ4Q.gif"
    elif user_message == "what time is it?":
        return "https://tenor.com/bVx5d.gif"
    else: 
        return "I don't know how to respond to that yet. :confused:"
