import discord
from discord.ext import commands
import asyncio
import responses
import os
import youtube_dl


intents = discord.Intents().all()
bot = commands.Bot(command_prefix='!', intents=intents)
client = discord.Client(intents=intents)


async def send_message(message, user_message):
    try:
        response = responses.what_response(user_message)
        await message.channel.send(response)
    except Exception as e:
        print(e)

async def after_certain_time(message, user_message):
    try:
            print(message)
            remind = user_message[6:]
            user_message = user_message.lower()
            
    except Exception as e:
            print(e)

async def get_last_bot_message_id(channel):
    try:
        async for message in channel.history(limit=50):
            if message.author == client.user:
                return message.id
    except Exception as e:
        print(e)

async def add_text_to_message(channel, message_id, text_to_add):
    try:
        message = await channel.fetch_message(message_id)
        new_content = message.content + " " + text_to_add
        await message.edit(content=new_content)
    except Exception as e:
        print(e)

async def help_response(message):
    try:
        print(message)
        user = message.author
        dm_channel = await user.create_dm()
        username = str(user.name)
        await dm_channel.send(f"Hello {username}!\nYou've asked me for help and here I am! Let me introduce you what can I do!")
        id_message = await get_last_bot_message_id(dm_channel)
        await asyncio.sleep(5)
        await add_text_to_message(dm_channel, id_message, "\n\nFirst thing you can ask me to do is show you how to use my built-in functions by writing '!help' as you just did. \nWhen written I will come to your dm to not spam server channels and tell you all you need to know about me!")
        await asyncio.sleep(5)
        await add_text_to_message(dm_channel, id_message, "\n\nThere's also a function that you can use by writing 'say: ' at beggining and later adding a sentence. If there is a prepared response then I will send the response to you.\nFor example:\nWhen user writes 'say: What time is it?' I will respond with:")
        await asyncio.sleep(1)
        await add_text_to_message(dm_channel, id_message,"https://tenor.com/bVx5d.gif")
        await asyncio.sleep(5)
        await add_text_to_message(dm_channel, id_message,"\n\nAnother function you can use is called by 'alarm in: ' to use it properly you can write for example 'alarm in: 01:05 Stop the rat race!'\nThis would make me send you a message after an hour and 5 minutes after the function was called.\nThe function was created to make life easier to people who easly forget about something and need to be reminded to do something after some time.\n(This was made mainly for my creator himself but you can also use it, don't worry.)")
        id_message = await get_last_bot_message_id(dm_channel)
        await asyncio.sleep(8)
        await add_text_to_message(dm_channel, id_message, "\n\nThat's all for now! Bye! Have a great day!")
        pass
    except Exception as e:
        print(e)




queues = {}

def run_friendlyface():
    @bot.event
    async def on_ready():
        print(f'Logged in as {bot.user}')

    DOWNLOADS_DIR = "/Downloads/"

    @bot.command()
    async def join(ctx):
        if ctx.author.voice is None:
            await ctx.send("You are not connected to a voice channel.")
            return

        voice_channel = ctx.author.voice.channel
        if ctx.voice_client is None:
            await voice_channel.connect()
        else:
            await ctx.voice_client.move_to(voice_channel)

    @bot.command()
    async def leave(ctx):
        if ctx.voice_client is not None:
            await ctx.voice_client.disconnect()
            clear_downloads(ctx.guild)
            queues[ctx.guild] = []
        else:
            await ctx.send("I am not connected to a voice channel.")

    @bot.command()
    async def play(ctx, url):
        if ctx.author.voice is None:
            await ctx.send("You are not connected to a voice channel.")
            return

        voice_channel = ctx.author.voice.channel
        if ctx.voice_client is None:
            await voice_channel.connect()
        else:
            await ctx.voice_client.move_to(voice_channel)

        if not os.path.exists(DOWNLOADS_DIR):
            os.makedirs(DOWNLOADS_DIR)

        try:
            ydl_opts = {
                'format': 'bestaudio/best',
                'outtmpl': f"{DOWNLOADS_DIR}%(id)s.%(ext)s",
                'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': '192',
                }],
            }

            with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                filename = f"{DOWNLOADS_DIR}{info['id']}.mp3"

            source = discord.FFmpegPCMAudio(filename)
            ctx.voice_client.stop()
            ctx.voice_client.play(source, after=lambda _: cleanup_file(filename))

        except youtube_dl.utils.DownloadError:
            await ctx.send("Failed to download and play the video. Please make sure the URL is valid and try again.")

    def cleanup_file(filename):
        if os.path.exists(filename):
            os.remove(filename)

    @bot.command()
    async def skip(ctx):
        if ctx.voice_client is not None and ctx.voice_client.is_playing():
            ctx.voice_client.stop()
            await ctx.send("Skipped.")
            if ctx.guild in queues and len(queues[ctx.guild]) > 0:
                await download_and_play(ctx, queues[ctx.guild][0])
                queues[ctx.guild].pop(0)
        else:
            await ctx.send("I am not playing any audio.")

    async def download_and_play(ctx, url):
        if not os.path.exists(DOWNLOADS_DIR):
            os.makedirs(DOWNLOADS_DIR)

        ydl_opts = {
            'format': 'bestaudio/best',
            'outtmpl': f"{DOWNLOADS_DIR}%(id)s.%(ext)s",
        }

        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            filename = f"{DOWNLOADS_DIR}{info['id']}.mp3"

        source = discord.FFmpegPCMAudio(filename)
        ctx.voice_client.stop()
        ctx.voice_client.play(source, after=lambda _: cleanup_file(filename))

    async def cleanup_file(filename):
        if os.path.exists(filename):
            os.remove(filename)

    def clear_downloads(guild):
        if guild in queues and len(queues[guild]) == 0:
            for file in os.listdir(DOWNLOADS_DIR):
                if file.endswith(".mp3"):
                    os.remove(os.path.join(DOWNLOADS_DIR, file))


    @bot.event
    async def on_message(message):
        if message.author == bot.user:
            return

        username = str(message.author)
        user_message = str(message.content)
        channel = str(message.channel)

        if user_message[:6] == "!say: ":
            user_message = user_message[6:]
            print(f"{username} said: '{user_message}' ({channel})")
            await send_message(message, user_message)

        elif user_message[:11] == "!alarm in: ":
            user_message = user_message[11:]
            print(f"{username} said: '{user_message}' ({channel})")
            await after_certain_time(message, user_message)

        elif user_message == "!help":
            print(f"{username} said: '{user_message}' ({channel})")
            await help_response(message)    
        try:
            await bot.process_commands(message)
        except Exception as e:
            print(e)

    bot.run("")


run_friendlyface()
